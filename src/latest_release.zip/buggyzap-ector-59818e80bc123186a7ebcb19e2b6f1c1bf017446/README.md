# Ector

An ultrafast prestashop theme based on concept of load only assets that Prestashop needs on the fly and only when needed.

## Why Ector?

Ector is a theme that is based on the concept of load only assets that Prestashop needs on the fly and only when needed. This is a concept that is not new, but it is not implemented in Prestashop by default, so we decided to do it.

This concept is based on the idea that Prestashop loads all the assets that the theme needs, even if the user is not in the page that needs that asset. This means that the user is loading more assets than he needs, and this is not good for the performance of the web.

So, we decided to do a theme that loads only the assets that the user needs, and loads them only when they are needed.

## How does it works?

The theme uses a concept of "loaders", that are small pieces of code that loads the assets that the user needs. For example, if the user is in the product page, the theme will load the assets that are needed in the product page, and if the user is in the category page, the theme will load the assets that are needed in the category page.

## How to use it?

This theme is designed to be used with the Ector core and Ector configurator as dependencies

## Prepare and check envs

Copy .env.dist to .env and replace values with your own

## Start the env the first time (this also build the image)

`make start-env`

And visit localhost::8085

## Start the env previously created

`make compose`

## Release management

### Create a new release of a module in interactive mode
`make release-interactive`

### Create a new release of a module in non-interactive mode, TYPE can be patch, minor or major
`make release MODULE=MODULE_NAME TYPE=TYPE_OF_RELEASE`

### Create a new release of all modules in non-interactive mode, TYPE can be patch, minor or major (change the suffix to change the type)
`make release-minor`