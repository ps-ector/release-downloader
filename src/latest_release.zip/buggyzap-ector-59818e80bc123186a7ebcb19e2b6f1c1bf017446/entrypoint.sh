#!/bin/bash

# Not implemented yet

echo "Executing the entrypoint script before ps install..."

# Install dependencies

echo "Installing ector_redis dependencies..."
cd /var/www/html/modules/ector_redis && composer install

if [ -d "/var/www/html/modules/ector_configurator" ]; then
    echo "Installing ector_configurator dependencies..."
    cd /var/www/html/modules/ector_configurator && composer install && composer dump-autoload -o
fi

# Rename ector_configurator to real_ector_configurator and fake_ector_configurator to ector_configurator
if [ -d "/var/www/html/modules/ector_configurator" ]; then
    echo "Renaming ector_configurator to real_ector_configurator and fake_ector_configurator to ector_configurator..."
    mv /var/www/html/modules/ector_configurator/ector_configurator.php /var/www/html/modules/ector_configurator/real_ector_configurator.php
    mv /var/www/html/modules/ector_configurator/fake_ector_configurator.php /var/www/html/modules/ector_configurator/ector_configurator.php
fi

if [ -d "/var/www/html/modules/ector_aws" ]; then
    echo "Installing ector_aws dependencies..."
    cd /var/www/html/modules/ector_aws && composer install
fi