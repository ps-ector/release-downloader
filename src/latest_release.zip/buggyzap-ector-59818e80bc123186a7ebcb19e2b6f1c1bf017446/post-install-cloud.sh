#!/bin/bash

# This file is intendeed to be used as a post-install script for the ector docker image on cloud environments

if [ -z "$1" ]; then
    echo "No theme name provided"
    echo "Usage: post-install-cloud.sh <theme-name>"
    exit 1
fi

THEME_CONFIG_PATH=/var/www/localhost/htdocs/config/themes/$1

sudo -u www-data mkdir -p "$THEME_CONFIG_PATH"
chown -R www-data:www-data /var/www/localhost/htdocs/*
