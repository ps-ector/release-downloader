# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.17] - 2023-09-27
### :bug: Bug Fixes
- [`2a64ec2`](https://github.com/buggyzap/ector/commit/2a64ec2c919799d37006700e717cbbbda9654382) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`bca208e`](https://github.com/buggyzap/ector/commit/bca208e93c9b5babb30101ed1412808fcac0a9e9) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`28bc4e8`](https://github.com/buggyzap/ector/commit/28bc4e823e21932b8dbfcfe7ea04375bfcfff3ce) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`c4812bd`](https://github.com/buggyzap/ector/commit/c4812bd504d3e44631c48994b3c95f424857d644) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`743a1ac`](https://github.com/buggyzap/ector/commit/743a1ac52d2db9b3a7dc0363e25d9e42bb34e5a4) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`03a22bf`](https://github.com/buggyzap/ector/commit/03a22bf289c5f416c433afa0b31662a0469d1069) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`060840b`](https://github.com/buggyzap/ector/commit/060840b6381be54e11559b5cd4d59882894222d6) - fixed workflow [skip ci] *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`a1026da`](https://github.com/buggyzap/ector/commit/a1026da42e1e203e5aed30df7d41818d5ef4086d) - **ci**: moved NodePort SVCs to TGB *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*
- [`951e306`](https://github.com/buggyzap/ector/commit/951e306186a1bf5daa6e48402c33cec4a1522133) - **ci**: moved NodePort SVCs to TGB *(commit by [@marcopalmisano](https://github.com/marcopalmisano))*


## [0.1.0] - 2023-07-13
### :sparkles: New Features
- [`5db8c3a`](https://github.com/buggyzap/ector/commit/5db8c3ada6f3475160460a4fca99a522e12eae6a) - updated submodules *(commit by [@buggyzap](https://github.com/buggyzap))*
- [`31602f3`](https://github.com/buggyzap/ector/commit/31602f3d895fcd1baae3ee5ea89d71a2d6d36da0) - latest merge changes coming from ps_pagano *(commit by [@buggyzap](https://github.com/buggyzap))*
- [`ae9905b`](https://github.com/buggyzap/ector/commit/ae9905b3bd79ebb3b98574edf432eeb19ce39890) - ask for confirmation *(commit by [@buggyzap](https://github.com/buggyzap))*

### :bug: Bug Fixes
- [`a3d523a`](https://github.com/buggyzap/ector/commit/a3d523a9806e3576a72e27322fd1a8e3ec070331) - compose-build at first time *(commit by [@buggyzap](https://github.com/buggyzap))*
- [`a53a4e8`](https://github.com/buggyzap/ector/commit/a53a4e8b4ab6ea7989b9e185e7b75b5731eee072) - readme typos and new customer.json *(commit by [@buggyzap](https://github.com/buggyzap))*
- [`6e93402`](https://github.com/buggyzap/ector/commit/6e93402a4bffb144f59d6286db2f31ace2a959a0) - header and docker *(commit by [@buggyzap](https://github.com/buggyzap))*
- [`73aa1a9`](https://github.com/buggyzap/ector/commit/73aa1a9c3099bb6a82867bb3f262f690bb295428) - header and submodule update *(commit by [@buggyzap](https://github.com/buggyzap))*


## [0.0.7] - 2023-07-07
### :bug: Bug Fixes
- [`66d929f`](https://github.com/buggyzap/ector/commit/66d929f00bac4ecdce7c55c74ee2bc80da672b6d) - build process *(commit by [@buggyzap](https://github.com/buggyzap))*


[0.0.7]: https://github.com/buggyzap/ector/compare/0.0.6...0.0.7
[0.1.0]: https://github.com/buggyzap/ector/compare/0.0.8...0.1.0
[1.0.17]: https://github.com/buggyzap/ector/compare/1.0.16-staging...1.0.17