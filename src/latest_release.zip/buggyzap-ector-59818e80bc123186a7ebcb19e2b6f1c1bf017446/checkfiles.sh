#!/bin/bash

# Check if the target folder argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: $0 <target_folder>"
  exit 1
fi

# Target folder to monitor
target_folder="$1"

# Name of the previous hash control file
previous_hash_file=".previous_hash"

# Folders to ignore (default settings)
ignore_folders=("vendor" "node_modules")

# Function to calculate the hash of a file
calculate_hash() {
  md5sum "$1" | awk '{print $1}'
}

# Check if the previous hash control file exists
if [ -e "$target_folder/$previous_hash_file" ]; then
  # Create an array with the hashes of the current files in the folder, excluding the control file itself
  declare -A current_hashes
  while IFS= read -r file; do
    if [ "$file" != "$target_folder/$previous_hash_file" ]; then
      current_hashes["$file"]=$(calculate_hash "$file")
    fi
  done < <(find "$target_folder" -type f -not \( -path "$target_folder/$previous_hash_file" -o -path "*/${ignore_folders[0]}/*" -o -path "*/${ignore_folders[1]}/*" \))

  # Read the previous hashes from the control file
  declare -A previous_hashes
  while IFS= read -r line; do
    file=$(echo "$line" | cut -d ' ' -f 1)
    hash=$(echo "$line" | cut -d ' ' -f 2)
    previous_hashes["$file"]=$hash
  done < "$target_folder/$previous_hash_file"

  # Compare the current hashes with the previous hashes
  files_modified=false
  for file in "${!current_hashes[@]}"; do
    if [ "${current_hashes["$file"]}" != "${previous_hashes["$file"]}" ]; then
      echo "File $file has been modified."
      files_modified=true
    fi
  done

  # If at least one file has been modified, update the hash control file
  if [ "$files_modified" = true ]; then
    echo "Updating the previous hash control file."
    > "$target_folder/$previous_hash_file"
    for file in "${!current_hashes[@]}"; do
      echo "$file ${current_hashes["$file"]}" >> "$target_folder/$previous_hash_file"
    done
  fi
else
  # If the previous hash control file doesn't exist, create the file and calculate the hashes
  echo "Creating the previous hash control file."
  > "$target_folder/$previous_hash_file"
  while IFS= read -r file; do
    if [ "$file" != "$target_folder/$previous_hash_file" ]; then
      hash=$(calculate_hash "$file")
      echo "$file $hash" >> "$target_folder/$previous_hash_file"
    fi
  done < <(find "$target_folder" -type f -not \( -path "$target_folder/$previous_hash_file" -o -path "*/${ignore_folders[0]}/*" -o -path "*/${ignore_folders[1]}/*" \))
  echo "The previous hash control file has been created."
fi
