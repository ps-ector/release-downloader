/** @type {import('tailwindcss').Config} */
const defaultTheme = require('tailwindcss/defaultTheme')
module.exports = {
  content: [
    './templates/**/*.tpl',
    './modules/**/*.tpl',
    './modules/**/*.js',
    './assets/js/*',
    '../modules/**/*.tpl',
    '../modules/**/*.js',
    '../assets/design_system.html',
    '!./node_modules/**/*',
    '!./modules/**/node_modules/**/*',
    '!../modules/**/node_modules/**/*'
  ],
  theme: {
    container: {
      padding: '2rem'
    },
    extend: {
      fontFamily: {
        serif: ['Inter', ...defaultTheme.fontFamily.serif]
      },
      colors: {
        pagano: {
          50: '#faf4ce',
          100: '#f1e8a9',
          200: '#e8db84',
          300: '#dfcf5f',
          400: '#d6c23a',
          500: '#cdb615',
          600: '#a59211',
          700: '#7c6e0d',
          800: '#544a08',
          900: '#2b2604'
        },
        mono: {
          100: '#e0e0e0',
          200: '#919191',
          400: '#7e7e7e',
          500: '#5f5f5f',
          700: '#1e1e1e'
        },
        dark: {
          50: '#7A7A7A',
          100: '#757575',
          200: '#5B5B5B',
          300: '#474747',
          400: '#323232',
          500: '#1E1E1E',
          600: '#191919',
          700: '#141414',
          800: '#0F0F0F',
          900: '#0A0A0A'
        }
      }
    }
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/line-clamp'),
    require('tailwind-container-break-out')
  ]
}
