import chokidar from 'chokidar'
import WebSocket from 'ws'

const wss = new WebSocket.Server({ port: 3666 })

const watcher = chokidar.watch([
  'templates/**/*.tpl',
  'assets/**/*.js',
  '../modules/**/*.js',
  '../modules/**/*.php',
  '../modules/**/*.tpl',
  '!./node_modules/**/*',
  '!../modules/**/node_modules/**/*',
  '!./modules/**/node_modules/**/*'
])

console.log('Watcher avviato')

watcher.on('change', () => {
  const message = { type: 'reload' }
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message))
    }
  })
})

wss.on('connection', (ws) => {
  console.log('Nuova connessione WebSocket')

  ws.on('close', () => {
    console.log('Connessione WebSocket chiusa')
  })
})
