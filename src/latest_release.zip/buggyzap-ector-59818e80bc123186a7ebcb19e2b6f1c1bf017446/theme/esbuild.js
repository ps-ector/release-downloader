import * as esbuild from 'esbuild'

const __DEV__ = process.env.NODE_ENV === 'development'
const __PROD__ = process.env.NODE_ENV === 'production'

if (process.argv.includes('--build')) {
  esbuild
    .build({
      entryPoints: ['__dev/index.js'],
      outfile: './assets/js/theme.js',
      bundle: true,
      sourcemap: false,
      minify: true,
      external: ['prestashop', 'jQuery', '$', 'Alpine'],
      target: ['chrome58', 'firefox57', 'safari11', 'edge18']
    })
    .then(() => console.log('build finish'))
    .catch(() => process.exit(1))
} else {
  const ctx = await esbuild.context({
    entryPoints: ['__dev/index.js'],
    outfile: './assets/js/theme.js',
    bundle: true,
    sourcemap: __DEV__,
    minify: __PROD__,
    target: ['chrome58', 'firefox57', 'safari11', 'edge18']
  })
  await ctx.watch()
  console.log('watching...')
}
