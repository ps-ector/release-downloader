module.exports = {
  env: {
    browser: true,
    es2021: true
  },
  extends: ['standard'],
  overrides: [],
  globals: {
    prestashop: 'readonly',
    $: 'readonly',
    jQuery: 'readonly',
    tns: 'readonly',
    Alpine: 'readonly',
    EctorCarousel: 'readonly'
  },
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module'
  },
  rules: {}
}
