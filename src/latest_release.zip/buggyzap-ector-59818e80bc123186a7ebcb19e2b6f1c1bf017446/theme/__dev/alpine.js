import { login, register, recovery } from './authentication'

document.addEventListener('alpine:init', () => {
  // generic dropdown object
  const dropdown = {
    open: false,
    toggle () {
      this.open = !this.open
    },
    show () {
      this.open = true
    },
    hide () {
      this.open = false
    }
  }

  // reuse dropdown object as Alpine component
  Alpine.data('dropdown', () => { return { ...dropdown } })

  Alpine.data('checkoutSteps', () => ({
    NEXT_INTENT: 'next',
    PREV_INTENT: 'prev',
    performStepValidations (step, intent) {
      // perform step validation from step 1 to 2
      if (step === 1 && intent === this.NEXT_INTENT) {
        // return false if there are any errors
        if ($('.errorsmall:visible').length > 0) {
          Alpine.store('ps').checkout.error = 'Alcune informazioni nel checkout sono incomplete o errate, controlla i campi prima di procedere'
          Alpine.store('ps').stepIsLocked = true
          return false
        }

        // re-trigger validations
        $('#shipping-new input:visible, #payment-new input:visible, #checkoutLogin input:visible').trigger('blur')

        // return false if there are any errors
        if ($('.errorsmall:visible').length > 0) {
          Alpine.store('ps').checkout.error = 'Alcune informazioni nel checkout sono incomplete o errate, controlla i campi prima di procedere'
          Alpine.store('ps').stepIsLocked = true
          return false
        }

        // unlock the step if pass all validations
        Alpine.store('ps').stepIsLocked = false
      }

      // reset errors before to continue checkout flow
      Alpine.store('ps').checkout.error = ''
      return true
    },
    nextStep () {
      const step = Alpine.store('ps').currentStep
      if (!this.performStepValidations(step, this.NEXT_INTENT)) return
      if (step + 1 <= 2) Alpine.store('ps').currentStep = step + 1
      this.dispatchByStepNumber(step + 1)
    },
    prevStep () {
      const step = Alpine.store('ps').currentStep
      if (!this.performStepValidations(step, this.PREV_INTENT)) return
      if (step - 1 >= 1) Alpine.store('ps').currentStep = step - 1
      this.dispatchByStepNumber(step - 1)
    },
    dispatchByStepNumber (step) {
      if (step < 1) {
        // redirect to cart
        window.location.href = prestashop.urls.pages.cart
      }
      if (step > 2) {
        // trigger confirm order
        document.getElementById('supercheckout_confirm_order').click()
      }
    }
  }))

  Alpine.store('ps', {
    couponActive: true,
    isProceeding: false,
    currentStep: 1,
    login,
    register,
    recovery,
    stepIsLocked: true,
    cartSummaryExist: false,
    wishlist: {
      isLoading: false,
      wished: false,
      count: 0
    },
    emailExist: false,
    // reuse dropdown object as Alpine store
    menu: { ...dropdown },
    isCheckingEmail: false,
    checkout: {
      error: ''
    },
    modal: {
      // modal html in footer.tpl
      open: false,
      isLoading: true,
      content: '',
      create () {
        this.isLoading = true
        this.setContent(prestashop.theme_context.getSpinner())
        this.show()
      },
      setContent (content) {
        this.content = content
      },
      hide () {
        Alpine.store('ps').backdrop.hide()
        this.open = false
      },
      show () {
        Alpine.store('ps').backdrop.show()
        this.open = true
      },
      toggle () {
        this.open = !this.open
      }
    },
    backdrop: {
      value: false,
      toggle () {
        this.value = !this.value
      },
      hide () {
        this.value = false
      },
      show () {
        this.value = true
      }
    },
    showLogin: {
      value: false,
      toggle () {
        // toggle backdrop
        Alpine.store('ps').backdrop.toggle()
        this.value = !this.value
      }
    }
  })
})
