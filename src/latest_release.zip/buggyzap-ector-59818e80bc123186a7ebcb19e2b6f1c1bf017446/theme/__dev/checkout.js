window.fillCheckoutDemoData = function (name) {
  const generateData = (name) => {
    const lastname = name + 'll' + name.charAt(name.length - 1)

    return {
      'shipping_address[firstname]': name,
      'shipping_address[lastname]': lastname,
      supercheckout_email: name.toLowerCase() + lastname.toLowerCase() + '@yopmail.com',
      'customer_personal[password]': name + lastname,
      'shipping_address[address1]': 'via mango 2a',
      'shipping_address[city]': 'Palermo',
      'shipping_address[postcode]': '90146',
      'shipping_address[phone_mobile]': '3334455667',
      'shipping_address[id_state]': 193
    }
  }

  const data = generateData(name)
  for (const key of Object.keys(data)) {
    document.querySelector(`[name="${key}"]`).value = data[key]
  }
}
