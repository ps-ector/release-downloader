/**
 * Facade class for carousel so we can instantiate any carousel we want without broke entire theme logic
 */
export default class EctorCarousel {
  static DEFAULT_CONFIG = {
    nav: true,
    controlsPosition: 'bottom',
    controls: true,
    preventScrollOnTouch: 'auto',
    controlsText: [
      '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.41436 13.0001L12.7073 19.293L11.293 20.7072L2.58594 12.0001L11.293 3.29297L12.7073 4.70718L6.41436 11.0001H21.0002V13.0001H6.41436Z" fill="black"/></svg>',
      `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.5858 13.0001H3V11.0001H17.5858L11.2929 4.70718L12.7071 3.29297L21.4142 12.0001L12.7071 20.7072L11.2929 19.293L17.5858 13.0001Z" fill="black"/>
</svg>`
    ],
    speed: 300,
    mouseDrag: true,
    onInit: () => {
    }
  }

  static types = [
    'productPage',
    'productGallery',
    'productGalleryTwo',
    'slider',
    'brandGallery'
  ]

  // this type of carousel is used in product page as main carousel of the page
  static productPageConfig = {
    items: 1,
    autoplay: false,
    gutter: 0,
    edgePadding: 0,
    lazyload: false,
    autoWidth: true,
    nav: true,
    controlsPosition: 'bottom',
    controls: false,
    controlsContainer: '#custom-product-controls',
    prevButton: '#prev-button',
    nextButton: '#next-button',
    slideBy: 'page',
    responsive: {
      420: {
        edgePadding: 0,
        controls: false
      },
      680: {
        edgePadding: 0,
        controls: true
      },
      1024: {
        edgePadding: 80,
        controls: true
      },
      1366: {
        edgePadding: 0,
        controls: true
      }
    },
    onInit: () => {
      $('.remove-after-init').remove()
    }
  }

  static productGalleryConfig = {
    items: 1,
    autoplay: false,
    gutter: 0,
    edgePadding: 128,
    lazyload: true,
    nav: true,
    navPosition: 'bottom',
    navContainer: '#carousel',
    loop: true,
    fixedWidth: 256,
    controlsPosition: 'bottom',
    controls: false,
    mouseDrag: true,
    touch: true,
    slideBy: 'page',
    onInit: () => {
      $('#tns1-mw').addClass('-ml-6 md:ml-0')
    },
    responsive: {
      420: {
        items: 1,
        edgePadding: 10
      },
      680: {
        items: 2,
        edgePadding: 10
      },
      1024: {
        items: 4,
        edgePadding: 40
      },
      1366: {
        items: 4,
        edgePadding: 40
      }
    }
  }

  static productGalleryTwoConfig = {
    items: 1,
    autoplay: false,
    gutter: 0,
    edgePadding: 128,
    lazyload: true,
    nav: true,
    navPosition: 'bottom',
    navContainer: '#carouselTwo',
    loop: true,
    fixedWidth: 256,
    controlsPosition: 'bottom',
    controls: false,
    mouseDrag: true,
    touch: true,
    slideBy: 'page',
    onInit: () => {
      $('#tns2-mw').addClass('-ml-6 md:ml-0')
    },
    responsive: {
      420: {
        items: 1,
        edgePadding: 10
      },
      680: {
        items: 2,
        edgePadding: 10
      },
      1024: {
        items: 4,
        edgePadding: 40
      },
      1366: {
        items: 4,
        edgePadding: 40
      }
    }
  }

  static sliderConfig = {
    items: 1,
    autoplay: false,
    autoplayButtonOutput: false,
    gutter: 0,
    edgePadding: 0,
    lazyload: false,
    nav: true,
    speed: 300,
    controls: true,
    navContainer: '#custom-nav',
    controlsContainer: '#custom-controls',
    prevButton: '#prev-button',
    nextButton: '#next-button',
    touch: true,
    slideBy: 'page',
    onInit: () => {
      $('#main-slides > li').removeClass('absolute sm:absolute md:absolute')
      $('#main-slides-title').addClass('flex')
      $('#main-slides-title > li').removeClass('sm:absolute md:absolute absolute')
      $('main-slides-title').attr('tabindex', -1)
      $('[data-controls="prev"]').attr('tabindex', 0)
      $('[data-controls="next"]').attr('tabindex', 0)
    }
  }

  static brandGalleryConfig = {
    items: 1,
    autoplay: false,
    autoWidth: false,
    gutter: 15,
    edgePadding: 30,
    lazyload: true,
    nav: true,
    navContainer: '#custom-nav-brands',
    loop: true,
    controls: true,
    touch: true,
    slideBy: 'page',
    responsive: {
      420: {
        items: 1,
        edgePadding: 30,
        gutter: 15
      },
      680: {
        items: 1,
        edgePadding: 30,
        gutter: 15
      },
      1024: {
        items: 1,
        edgePadding: 30,
        gutter: 15
      },
      1366: {
        items: 1,
        edgePadding: 30,
        gutter: 15
      }
    },
    onInit: () => {
      $('#brands-carousel-mw').css('margin-right', '-1rem')
    }
  }

  // Create carousel instance by given selector and type
  static createInstance (selector, type) {
    // check if element exists
    if ($(selector).length === 0) {
      console.log(`Carousel element ${selector} does not exist`)
      return
    }

    // check if type is valid
    if (!this.types.includes(type)) {
      console.error(`Carousel type ${type} is not valid`)
    }

    // merge default config with type config
    const config = Object.assign(this.DEFAULT_CONFIG, this[`${type}Config`])

    return tns({
      container: selector,
      ...config
    })
  }
}

// expose to real world
window.EctorCarousel = EctorCarousel
