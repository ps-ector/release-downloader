const controllerUrl = prestashop.urls.pages.index + 'checkout?ajax=true'

export const login = {
  attempt: async function (email, password) {
    this.isLoading = true
    try {
      const login = await fetch(controllerUrl + '&method=loginUser', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'email=' + email + '&password=' + password
      })
      const { response } = await login.json()
      if (response) {
        this.success = true
        this.error = false
        setTimeout(() => {
          location.reload(true)
        }, 2000)
      } else {
        this.success = false
        this.error = true
      }
    } catch (error) {
      this.error = true
    }
    this.isLoading = false
  },
  isLoading: false,
  error: false,
  success: false
}

export const register = {
  attempt: async function (name, surname, email, password, passwordConfirmation, terms) {
    this.isLoading = true
    try {
      const register = await fetch(controllerUrl + '&method=registerUser', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body:
            'name=' + name +
            '&surname=' + surname +
            '&email=' + email +
            '&password=' + password +
            '&passwordConfirmation=' + passwordConfirmation +
            '&terms=' + terms
      })
      const { response, errors } = await register.json()
      if (response) {
        this.success = true
        this.error = []
        setTimeout(() => {
          location.reload(true)
        }, 2000)
      } else {
        this.success = false
        this.error = errors
      }
    } catch (error) {
      this.error = error
    }
    this.isLoading = false
  },
  isLoading: false,
  error: [],
  success: false
}

export const recovery = {
  attempt: async function (email) {
    this.isLoading = true
    try {
      const recovery = await fetch(controllerUrl + '&method=recoveryUser', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body:
            'email=' + email
      })
      const { response } = await recovery.json()
      if (response) {
        this.success = true
        this.error = false
        setTimeout(() => {
          location.reload(true)
        }, 2000)
      } else {
        this.success = false
        this.error = true
      }
    } catch (error) {
      this.error = true
    }
    this.isLoading = false
  },
  isLoading: false,
  error: false,
  success: false
}
