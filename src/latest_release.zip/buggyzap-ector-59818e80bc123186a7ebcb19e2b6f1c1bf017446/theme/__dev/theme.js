import EventEmitter from 'events'
import { notification } from './notification'

// This will fix the missing EventEmmiter in Prestashop new theme
for (const i in EventEmitter.prototype) {
  prestashop[i] = EventEmitter.prototype[i]
}

prestashop.theme_context = {}
prestashop.theme_context.overdrop = []

prestashop.theme_context.registerOverdrop = (el) =>
  prestashop.theme_context.overdrop.push(el)

prestashop.theme_context.closeAllOverdrop = () => {
  $('.theme-backdrop').addClass('hidden')
  prestashop.theme_context.overdrop.forEach((item, i) => {
    item.close()
  })
}

window.console.trace = null

prestashop.theme_context.getSpinner = (size = 1) => {
  const sizeClass = 'w-' + 4 * size + ' h-' + 4 * size
  return `
  <div class="absolute z-10 inset-0 bg-white/75 spinner-backdrop"></div>
  <div role="status" class="absolute inset-0 z-20 -translate-x-1/2 left-[50%] top-[50%] -translate-y-1/2 flex items-center justify-center temp-spinner">
    <svg class="inline ${sizeClass} text-gray-200 animate-spin dark:text-gray-600 fill-dark-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
      <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/>
    </svg>
    <span class="sr-only">Loading...</span>
  </div>
  `
}

prestashop.theme_context.load = (el, size = 1) => {
  $(el).addClass('relative')
  const spinner = prestashop.theme_context.getSpinner(size)
  $(el).prepend(spinner)
}

prestashop.theme_context.unload = (el) => {
  $(el).removeClass('relative')
  $(el).find('.spinner-backdrop, .temp-spinner').remove()
}

prestashop.theme_context.highlightSection = (selector) => {
  $(selector).addClass('bg-red-100')
  // scroll to selector
  $('html, body').animate(
    {
      scrollTop: $(selector).offset().top - 100
    },
    200
  )
  setTimeout(() => {
    $(selector).removeClass('bg-red-100')
  }, 1000)
}

prestashop.theme_context.checkEmailExists = async (el) => {
  const value = el.target.value
  const url = prestashop.urls.current_url
  const data = {
    method: 'emailExists',
    ajax: true,
    email: value
  }

  // check email with regex
  const regex = /\S+@\S+\.\S+/
  if (!regex.test(value)) {
    Alpine.store('ps').emailExist = false
    return false
  }
  Alpine.store('ps').isCheckingEmail = true
  const result = await $.ajax({
    url,
    method: 'POST',
    data
  })
  Alpine.store('ps').emailExist = result !== 'false'
  Alpine.store('ps').isCheckingEmail = false
  return result
}

prestashop.theme_context.notification = notification

function triggerChangedProductQty (el) {
  const newQty = parseInt($(el).val())
  const originalQty = parseInt($(el).attr('data-original-qty'))
  const op = newQty < originalQty ? 'down' : 'up'
  const qtyToSet = newQty - originalQty
  const url = $(el).attr('data-up-url')
  const requestData = {
    ajax: '1',
    qty: Math.abs(qtyToSet),
    action: 'update',
    op
  }
  prestashop.theme_context.load($(el).closest('div'))
  $.ajax({
    url,
    method: 'POST',
    data: requestData,
    dataType: 'json'
  })
    .then((resp) => {
      $(el).val(resp.quantity)
      $(el).attr('data-original-qty', resp.quantity)
      const dataset = $(el) && $(el).dataset ? $(el).dataset : resp
      prestashop.theme_context.unload(el)
      // Refresh cart preview
      prestashop.emit('updateCart', {
        reason: dataset,
        resp
      })
    })
    .fail((resp) => {
      prestashop.theme_context.unload($(el).closest('div'))
      prestashop.emit('handleError', {
        eventType: 'updateProductQuantityInCart',
        resp
      })
    })
}

function handleChangeQuantity () {
  const op = $(this).attr('data-op')
  const whereInput = op === 'up' ? 'prev' : 'next'
  op === 'up'
    ? $(this)[whereInput]().val(parseInt($(this)[whereInput]().val()) + 1)
    : $(this)[whereInput]().val(parseInt($(this)[whereInput]().val()) - 1)
  if (parseInt($(this)[whereInput]().val()) <= 0) {
    $(this)[whereInput]().val(1)
  }
  triggerChangedProductQty($(this)[whereInput]())
}

function capitalizeFirstLetter (string) {
  return string.charAt(0).toUpperCase() + string.slice(1)
}

$(document).ready(function () {
  if (prestashop.page.page_name === 'manufacturer') {
    EctorCarousel.createInstance('#main-slides', 'slider')
    EctorCarousel.createInstance('#main-slides-title', 'slider')
  }

  if (prestashop.page.page_name === 'index') {
    EctorCarousel.createInstance('#main-slides', 'slider')
    EctorCarousel.createInstance('#main-slides-title', 'slider')

    EctorCarousel.createInstance('#man-carousel .carousel', 'productGallery')
    EctorCarousel.createInstance(
      '#woman-carousel .carousel',
      'productGalleryTwo'
    )
    if ($(window).width() < 1024) {
      EctorCarousel.createInstance('#brands-carousel', 'brandGallery')
    }
  }
  if (prestashop.page.page_name === 'product') {
    EctorCarousel.createInstance('#product-carousel', 'productPage')
    EctorCarousel.createInstance(
      '.product_carousel_accessories',
      'productGallery'
    )
  }

  if ($('#product').length) {
    prestashop.on('updatedProduct', function () {
      EctorCarousel.createInstance('#product-carousel', 'productPage')
    })

    const hash = location.hash
    const attributes = hash.split('/')
    let colorToSelect = ''
    $.each(attributes, function (k, v) {
      if (v.includes('color-')) {
        const colorToSelectSplitted = v.split('-')
        colorToSelect = colorToSelectSplitted[colorToSelectSplitted.length - 1]
        colorToSelect = capitalizeFirstLetter(colorToSelect.replace('_', '-'))
      }
    })
    if (colorToSelect !== '') {
      const targetColorEl = $("span:contains('" + colorToSelect + "')")
        .closest('label')
        .find('.input-color')
      const checkedColor = $('.input-color:checked')
      if (!checkedColor.is(targetColorEl)) {
        targetColorEl.prop('checked', true)
      }
      prestashop.emit('updateProduct', {})
    }
  }

  $('.theme-backdrop').on('click', prestashop.theme_context.closeAllOverdrop)

  $(document).on(
    'click',
    '.cart-update-product-quantity',
    handleChangeQuantity
  )

  $(document).on('change', '.cart-update-product-quantity-input', function () {
    triggerChangedProductQty(this)
  })

  $('#megamenu-mobile li.has_sub').on('click', function () {
    $(this).toggleClass('open')
    $(this).find('ul').toggleClass('hidden flex')
  })

  $('.menu-reset').on('click', function () {
    $(this).closest('has_sub').removeClass('open')
    $(this)
      .closest('has_sub')
      .find('ul')
      .removeClass('flex')
      .addClass('hidden')
  })

  $('button[data-menu]').on('click', function () {
    const menu = $(this).attr('data-menu')
    $('button[data-menu]').removeClass('underline-selected')
    $(this).addClass('underline-selected')
    $('#ul-menu-container > ul').removeClass('flex').addClass('hidden')
    $("ul[data-menu='" + menu + "']")
      .removeClass('hidden')
      .addClass('flex')
  })

  $('.toggle-link-menu').on('click', function () {
    const ulEl = $(this).closest('.links').find('ul')
    const isOpen = ulEl.css('max-height') !== '0px'
    ulEl.css('max-height', isOpen ? '0px' : '300px')
    $(this).find('svg').hide(0)
    $(this)
      .find('svg')
      .eq(isOpen ? 0 : 1)
      .show(0)
  })

  prestashop.on('handleError', function (event) {
    prestashop.theme_context.notification.error(
      'Oops!',
      event.resp.errors.join('<br>')
    )
  })

  prestashop.on('updateCart', function (event) {
    console.log(event)
    if (event.reason.linkAction === 'add-to-cart' && event.resp.success) {
      prestashop.theme_context.notification.success(
        'Carrello',
        'Prodotto aggiunto al carrello'
      )
    }
  })
})
