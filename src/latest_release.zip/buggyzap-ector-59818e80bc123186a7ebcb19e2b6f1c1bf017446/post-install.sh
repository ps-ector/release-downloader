#!/bin/bash

# This file is intendeed to be used as a post-install script for the ector docker image on local environments

echo "Executing the post-install script after ps install..."

if [ -d "/var/www/html/modules/ector_cli" ]; then
    echo "Installing ector_cli dependencies..."
    cd /var/www/html/modules/ector_cli && composer install && composer dump-autoload -o
fi

if [ -d "/var/www/html/modules/ector_psadmin" ]; then
    echo "Installing ector_psadmin dependencies..."
    cd /var/www/html/modules/ector_psadmin && composer install && composer dump-autoload -o
fi

if [ -d "/var/www/html/modules/ector_omnibus" ]; then
    echo "Installing ector_omnibus dependencies..."
    cd /var/www/html/modules/ector_omnibus && composer install && composer dump-autoload -o
fi

# Rename ector_configurator to fake_ector_configurator and real_ector_configurator to ector_configurator
if [ -d "/var/www/html/modules/ector_configurator" ]; then
    echo "Renaming ector_configurator to fake_ector_configurator and real_ector_configurator to ector_configurator..."
    mv /var/www/html/modules/ector_configurator/ector_configurator.php /var/www/html/modules/ector_configurator/fake_ector_configurator.php
    mv /var/www/html/modules/ector_configurator/real_ector_configurator.php /var/www/html/modules/ector_configurator/ector_configurator.php
fi

# Enable ector theme
php /var/www/html/bin/console prestashop:theme:enable ector

# execute post-install.php for operations that need to be done after the installation on php environment
php /var/www/html/post-install.php && echo "Post-install script executed successfully!"

# setup permissions on used folder
chown -R www-data:www-data /var/www/html/var && echo "Permissions on /var/www/html/var set successfully!"
